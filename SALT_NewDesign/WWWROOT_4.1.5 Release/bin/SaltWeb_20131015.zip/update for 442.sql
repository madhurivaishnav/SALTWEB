USE [salt_4.3.0]
GO
/****** Object:  StoredProcedure [dbo].[prcSCORMgetValue]    Script Date: 10/10/2013 10:04:27 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[prcSCORMgetValue] (
             @StudentID int,
             @LessonID int,
             @DME  varchar(50)
           )  
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
if @DME='cmi.core.lesson_location'
begin
		SELECT  Q.lectoraBookmark from tblLesson L 
		inner join tblQuiz Q on L.ModuleID =  Q.ModuleID where L.Active = 1 and Q.Active = 1 and L.lessonID = @lessonID
end
else
begin
	SELECT [value] FROM  tblScormDME
           WHERE UserID = @StudentID
           and LessonID = @LessonID
           and DME = @DME
end
END


GO



IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcSCORMgetSession]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcSCORMgetSession]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[prcSCORMgetSession] (
             @StudentID int,
             @LessonID int,
            @isLesson bit  
           )  
AS
BEGIN
	SET NOCOUNT ON;
DECLARE @RC int
DECLARE @OrganisationID int
DECLARE @NumQuestions int
DECLARE @quizpassmark int
DECLARE @Name nvarchar(255)
SET @Name = N'Number_Of_Quiz_Questions'
SELECT @OrganisationID = OrganisationID FROM tblUser WHERE UserID = @StudentID
SELECT @quizpassmark = DefaultQuizPassMark FROM tblOrganisation WHERE OrganisationID = @organisationID 
--EXECUTE @NumQuestions = prcOrganisationConfig_GetOne  @organisationID = @OrganisationID, @name = @Name



If Exists (Select OrganisationID From tblOrganisationConfig Where OrganisationID = @organisationID And [Name]	= @Name)
Begin
	Select @NumQuestions = value from tblOrganisationConfig Where OrganisationID	= @OrganisationID And [Name]		= @Name 
End
Else
Begin
	Select @NumQuestions = Value From tblOrganisationConfig Where OrganisationID	is null And  [Name]		= @Name 
End

   if @isLesson = 1
   begin   
        Declare @LectoraBookmark nvarchar(100) 
        SELECT @LectoraBookmark = Q.lectoraBookmark from tblLesson L 
				inner join tblQuiz Q on L.ModuleID =  Q.ModuleID where L.Active = 1 and Q.Active = 1 and L.moduleID = @lessonID   
		SELECT DME,value FROM  tblScormDME
			   WHERE UserID = @StudentID
				and LessonID = @LessonID
				and DME <> 'salt.lessonorquiz'
				and DME <> 'salt.training.QuizURL2'
				and DME NOT LIKE 'cmi.interactions%'
		UNION SELECT 'salt.lessonorquiz' as DME, 'lesson' as [value]		
		UNION SELECT 'salt.training.QuizURL2' as DME, @LectoraBookmark as [value]
	end
	else
	begin
		
		-- delete the existing quiz dmes
		delete from tblScormDME 
		where UserID  =@StudentID and LessonID =@LessonID
		and DME in ('cmi.core.student_id','cmi.core.student_name','cmi.core.version','cmi.core.numrandom','cmi.core.quizpassmark')
		
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.student_id' ,'Salt�'+CAST(@StudentID AS varchar(20)))
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.student_name' ,(SELECT FirstName FROM tblUser WHERE UserID = @StudentID))
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.version' ,'3.4')
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.numrandom' ,@NumQuestions ) 
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.quizpassmark' ,@quizpassmark)
	    Declare @QuizBookmark varchar(1000)
		SELECT @QuizBookmark =   Q.lectoraBookmark from tblLesson L 
				inner join tblQuiz Q on L.ModuleID =  Q.ModuleID where L.Active = 1 and Q.Active = 1 and L.moduleID = @lessonID  		
		SELECT DME,value FROM  tblScormDME
				 WHERE UserID = @StudentID
					and LessonID = @LessonID
				and DME <> 'cmi.core.lesson_location'
				and DME <> 'salt.lessonorquiz'
				and DME NOT LIKE 'cmi.interactions%'				
		UNION SELECT 'cmi.core.lesson_location' AS DME, @QuizBookmark as [value]
		UNION SELECT 'salt.lessonorquiz' as DME, 'quiz' as [value]	
	end

END


GO





IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcSCORMtrainQandA]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcSCORMtrainQandA]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[prcSCORMtrainQandA] 
(
	@StudentID int,
    @intModuleID Int,
    @intAskedQuestion Int,
    @intWeighting Int,
    @strLatency NVarChar(100),
    @strTime NVarChar(100),
    @strText NVarChar(1000), 
    @strCorrectResponse NVarChar(1000), 
    @strStudentResponse NVarChar(1000), 
    @strType NVarChar(100), 
    @strID NVarChar(100), 
    @isCorrect Bit
)
as
begin
		declare @strQuizSessionID nvarchar(1000)

        SELECT @strQuizSessionID =  (SELECT top 1 quizSessionID
		FROM tblQuiz Q
		inner join tblQuizSession QS on  Q.QuizID = QS.QuizID 
		WHERE Q.Active = 1 AND QS.DateTimeStarted IS NOT NULL
		--AND QS.DateTimeCompleted IS NULL
		AND Q.ModuleID = @intModuleID
		AND QS.UserID = @StudentID
		order by DateTimeStarted desc)
		
		IF (@strQuizSessionID IS NOT NULL)
		BEGIN
			declare @intQuizID int;

			set @intQuizID = (
					select top 1 QuizID
					from tblQuiz
					where moduleID = @intModuleID
						and Active = 1
					)

			declare @QuizQuestionID int

			select @QuizQuestionID = (
					select top 1 QuizQuestionID
					from tblQuizQuestion
					where QuizID = @intQuizID
						and ToolbookPageID = @strID
						and Question = @strText
					)

			if (@QuizQuestionID is null)
			begin
				delete
				from tblQuizQuestion
				where QuizID = @intQuizID
					and ToolbookPageID = @strID

				insert tblQuizQuestion (
					QuizID
					,ToolbookPageID
					,Question
					)
				values (
					@intQuizID
					,@strID
					,@strText
					)
				select @QuizQuestionID = @@IDENTITY
			end

			declare @QuizAnswerID int
			--
			select @QuizAnswerID = (
					select top 1 QuizAnswerID
					from tblQuizAnswer
					where QuizQuestionID = @QuizQuestionID
						and ToolbookAnswerID = SUBSTRING(@strStudentResponse,0,49)
						and Answer = @strStudentResponse
					)

			if (@QuizAnswerID is null)
			begin
				delete
				from tblQuizAnswer
				where QuizQuestionID = @QuizQuestionID
					and ToolbookAnswerID = SUBSTRING(@strStudentResponse,0,49)

				insert tblQuizAnswer (
					QuizQuestionID
					,ToolbookAnswerID
					,Answer
					,correct
					)
				values (
					@QuizQuestionID
					,SUBSTRING(@strStudentResponse,0,49)
					,@strStudentResponse
					,@isCorrect
					)
				select @QuizAnswerID = @@IDENTITY
			end
			
			declare @QuizCorrectAnswerID int
			select @QuizCorrectAnswerID = (
					select top 1 QuizAnswerID
					from tblQuizAnswer
					where QuizQuestionID = @QuizQuestionID
						and ToolbookAnswerID = SUBSTRING(@strCorrectResponse,0,49)
						and Answer = @strCorrectResponse
					)

			if (@QuizCorrectAnswerID is null)
			begin
				delete
				from tblQuizAnswer
				where QuizQuestionID = @QuizQuestionID
					and ToolbookAnswerID = SUBSTRING(@strCorrectResponse,0,49)

				insert tblQuizAnswer (
					QuizQuestionID
					,ToolbookAnswerID
					,Answer
					,correct
					)
				values (
					@QuizQuestionID
					,SUBSTRING(@strCorrectResponse,0,49)
					,@strCorrectResponse
					,@isCorrect
					)
				select @QuizCorrectAnswerID = @@IDENTITY
					
			end
			
			IF NOT EXISTS (SELECT * FROM tblQuizQuestionAudit WHERE QuizSessionID = @strQuizSessionID AND QuizQuestionID = @QuizQuestionID)
			BEGIN
				INSERT INTO tblQuizQuestionAudit( QuizSessionID,QuizQuestionID,Duration,DateAccessed)
				VALUES  (@strQuizSessionID, @QuizQuestionID, 46664, getUTCdate())
			END
			if not exists (SELECT * FROM tblQuizAnswerAudit WHERE QuizSessionID = @strQuizSessionID AND QuizQuestionID = @QuizQuestionID AND QuizAnswerID = @QuizAnswerID)
			BEGIN
				INSERT INTO tblQuizAnswerAudit (QuizSessionID,QuizQuestionID,QuizAnswerID)
				values (@strQuizSessionID,@QuizQuestionID,@QuizAnswerID) 
			END
		END

 end
GO


DROP PROCEDURE [dbo].[prcEscalationConfigForCourse_Update]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[prcEscalationConfigForCourse_Update]
(
	@remEscID int = -1,
	@orgID int ,
	@courseIDs varchar(max)  = '',
	@updateOption int =-1,
	@DaysToCompleteCourse int,
	@RemindUsers bit=0,
	@NumOfRemNotfy int =-1,
	@RepeatRem int =-1,
	@NotifyMgr bit =0,
	@IndividualNotification bit =0,
	@IsCumulative bit =0,
	@NotifyMgrDays int=-1,
	@QuizExpiryWarn bit =0,
	@DaysQuizExpiry int =-1,
	@preexpiryInitEnrolment bit =0,
	@postExpReminder bit = 0,
	@postExpInitEnrolment bit = 0,
	@postExpResitPeriod bit = 0,
	@preExpResitPeriod bit = 0
)
AS
BEGIN

		--update existing ones
		update
		tblReminderEscalation
		set
		DaysToCompleteCourse = @DaysToCompleteCourse,
		RemindUsers = @RemindUsers,
		NumOfRemNotfy = @NumOfRemNotfy,
		RepeatRem = @RepeatRem,
		NotifyMgr = @NotifyMgr,
		IsCumulative = @IsCumulative,
		QuizExpiryWarn = @QuizExpiryWarn,
		DaysQuizExpiry = @DaysQuizExpiry,		
		NotifyMgrDays = @NotifyMgrDays,
		IndividualNotification = @IndividualNotification,
		PreExpInitEnrolment = @preexpiryInitEnrolment,
		PostExpReminder =@postExpReminder,
		PostExpInitEnrolment = @postExpInitEnrolment,
		PostExpResitPeriod = @postExpResitPeriod,
		PreExpResitPeriod = @preExpResitPeriod
		
		where
		OrgId =@orgID
		and CourseId IN (SELECT * FROM dbo.udfCsvToInt(@courseIDs))
	
		insert into tblReminderEscalation (
		OrgId,
		CourseId,
		DaysToCompleteCourse,
		RemindUsers,
		NumOfRemNotfy,
		RepeatRem,
		NotifyMgr,
		IsCumulative,
		QuizExpiryWarn,
		DaysQuizExpiry,
		NotifyMgrDays,
		IndividualNotification,
		PreExpInitEnrolment,
		PostExpReminder,
		PostExpInitEnrolment,
		PostExpResitPeriod,
		PreExpResitPeriod,
		DateEnabled
		)
		select 
		@orgID,
		c.CourseID,
		@DaysToCompleteCourse,
		@RemindUsers,
		@NumOfRemNotfy,
		@RepeatRem,
		@NotifyMgr,
		@IsCumulative,
		@QuizExpiryWarn,
		@DaysQuizExpiry,
		@NotifyMgrDays,
		@IndividualNotification,
		@preexpiryInitEnrolment,
		@postExpReminder,
		@postExpInitEnrolment,
		@postExpResitPeriod,
		@preExpResitPeriod,
		GETUTCDATE()
		from tblCourse c
		left join tblReminderEscalation re on re.CourseId = c.CourseID and re.OrgId = @orgID
		where re.CourseId is null and c.CourseID IN (SELECT * FROM dbo.udfCsvToInt(@courseIDs))
		
END
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcSCORMimport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcSCORMimport]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[prcSCORMimport]
@intModuleID integer,
@strToolLocation varchar(100),
@strQFSLocation varchar(100),
@DatePublished datetime,
@intUserID integer,
@SCORMsource varchar(100)
AS
BEGIN
--Set @intLessonID 	= dbo.udfGetLessonIDByToolbookIDAndModuleID (@strToolbookID,@intModuleID)


Declare @LWorkSiteID nvarchar(50)
Declare @QFWorkSiteID nvarchar(50)
Declare @intLessonID integer
Declare @intquizID integer

Select @LWorkSiteID = LWorkSiteID, @QFWorkSiteID = QFWorkSiteID From tblLesson Where LessonID = @intLessonID

---- Deactivate the existing lesson if it exists
Begin
Update
tblLesson
Set
Active = 0
Where
ModuleID = @intModuleID
End


-- Create the new lesson
Insert Into tblLesson
(
ModuleID,
ToolbookID,
ToolbookLocation,
QFSlocation,
DatePublished,
LoadedBy,
DateLoaded,
Active,
LWorkSiteID,
QFWorkSiteID,
Scorm1_2
)
-- With the values from the old lesson
VALUES
(
@intModuleID,
'SCOnew',
@strToolLocation,
@strQFSLocation,
@DatePublished,
@intUserID,		-- Loaded By
GETDATE(),		-- Date Loaded
1,				-- Active
@LWorkSiteID,
@QFWorkSiteID,
1
)
-- Get the new lesson id
SELECT 	@intLessonID =  LessonID FROM tblLesson where Active = 1 AND ModuleID = @intModuleID

UPDATE tblLesson set ToolbookID = 'SCO' + CAST(LessonID as varchar(9)) WHERE LessonID = @intLessonID

-- Insert the new lesson pages
Insert Into tblLessonPage
(
LessonID,
ToolbookPageID,
Title
)

Select
@intLessonID,
'SCORM 1.2 lesson',
'IFRAME 1.2'

--delete bookmarks to old content
DELETE FROM tblScormDME where lessonID = @intModuleID

Declare @QuizLaunchPoint nvarchar(100)
SELECT @QuizLaunchPoint =   COALESCE(QuizLaunchPoint,' ') FROM tblSCORMcontent WHERE LessonLaunchPoint = @SCORMsource 
IF @QuizLaunchPoint <> ' '
BEGIN

    Declare @strToolLocationReverse varchar(100)
    Declare  @strToolDirectory varchar(100)
    SELECT @strToolLocationReverse = reverse (@strToolLocation)
    SELECT @strToolDirectory = substring(@strToolLocation,1, LEN(@strToolLocation)-CHARINDEX ( '/' ,@strToolLocationReverse)  ) 
	Update tblQuiz Set Active = 0 Where ModuleID = @intModuleID
	INSERT INTO tblQuiz
           ([ModuleID]
           ,[ToolbookID]
           ,[ToolbookLocation]
           ,[DatePublished]
           ,[LoadedBy]
           ,[DateLoaded]
           ,[Active]
           ,[WorksiteID]
           ,Scorm1_2
           ,LectoraBookmark    )
     VALUES
           (@intModuleID
           ,'SCO'
           ,replace(@strToolLocation, '/a001index.html','/'+@QuizLaunchPoint )
           -- ,@strToolDirectory +'/'+@QuizLaunchPoint
           ,@DatePublished
           ,1
           ,getUTCdate()
           ,1
           ,null,1
           ,@QuizLaunchPoint  )
         SELECT 	@intquizID =  quizID FROM tblQuiz where Active = 1 AND ModuleID = @intModuleID

UPDATE tblQuiz set ToolbookID = 'SCO' + CAST(quizID as varchar(9)) WHERE quizID = @intquizID  
END

SELECT @intLessonID
END

GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcQuizSession_GetEndQuizInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcQuizSession_GetEndQuizInfo]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


/*Summary:
read all information needed to end a quiz

Returns:
data table

Called By:
ToolBook.cs: GetEndQuizInfo

Remarks:

QuizStatusID Status
------------ --------------------------------------------------
0            Unassigned
1            Not Started
2            Passed
3            Failed
4            Expired (Time Elapsed)
5            Expired (New Content)

Author: Li Zhang
Date Created: 13-10-2006
Modification History
-----------------------------------------------------------
v#	Author		Date			Description
#1	mikev		1/5/2007		Added LessonCompletionDate
**/

CREATE PROCEDURE [dbo].[prcQuizSession_GetEndQuizInfo]
(
@quizSessionID varchar(50) -- unique that identifies this toolbook quiz session
, @duration int -- time used to complete the quiz
, @score int -- user quiz score
)
AS
SET nocount on
BEGIN
DECLARE @intUserID	int	-- user id
,		@intQuizID	int -- quiz id
,		@intPassMark	int	-- quiz pass mark
,		@intUnitID	int	-- user's unit id
,		@intModuleID	int -- quiz module id
,		@intCourseID	int -- module course id
,		@intOldCourseStatus	int -- course status before update
,		@intNewQuizStatus int -- the quiz status
, 		@intNewCourseStatus	int	-- course status after update
,		@intQuizFrequency int
,		@dtmQuizCompletionDate datetime
DECLARE	@tblUserEndQuizInfo table	-- return table with all details needed to end a quiz
(
UserID	int
, QuizID int
, PassMark int
, UnitID int
, ModuleID int
, QuizFrequency int
, QuizCompletionDate datetime
, NewQuizStatus int
, OldCourseStatus int
, NewCourseStatus int
, CourseID int
, sendcert bit

)

--< read required data >--

SET @intUserID = dbo.udfGetUserIDBySessionID(@quizSessionID)
SET @intQuizID = dbo.udfGetQuizIDBySessionID(@quizSessionID)
SELECT @intUnitID = (SELECT TOP 1 UnitID FROM tblUser WHERE UserID = @intUserID)
SELECT @intModuleID = (SELECT TOP 1 ModuleID FROM tblQuiz WHERE QuizID = @intQuizID)
SET @intPassMark = dbo.udfQuiz_GetPassMark(@intUnitID, @intModuleID)
IF @score < @intPassMark
BEGIN
--< Quiz status: failed >--
SET @intNewQuizStatus = 3
END
IF @score > @intPassMark OR @score = @intPassMark
BEGIN
--< Quiz status: passed >--
SET @intNewQuizStatus = 2
END

SELECT @intCourseID = (SELECT TOP 1 CourseID FROM tblModule WHERE ModuleID = @intModuleID)
EXEC @intOldCourseStatus = prcUserCourseStatus_GetStatus @intCourseID, @intUserID
EXEC @intNewCourseStatus = prcUserCourseStatus_Calc @intCourseID, @intUserID,  @intNewQuizStatus,@intModuleID

--< get pre-defined quiz frequency from tblUnitRule >--
--< if the value is null then use the default quiz frequency in tblOrganisation >--

-- mikev(1): added QuizCompletionDate
SET @intQuizFrequency = (
SELECT  TOP 1   ISNULL(ur.QuizFrequency, o.DefaultQuizFrequency)
FROM   	tblUnitRule AS ur INNER JOIN tblUser AS u
ON ur.UnitID = u.UnitID
INNER JOIN tblOrganisation AS o ON u.OrganisationID = o.OrganisationID
WHERE	u.UserID = @intUserID
)

SET @dtmQuizCompletionDate = (
SELECT  TOP 1	ISNULL(ur.QuizCompletionDate, o.DefaultQuizCompletionDate)
FROM   	tblUnitRule AS ur INNER JOIN tblUser AS u
ON ur.UnitID = u.UnitID
INNER JOIN tblOrganisation AS o ON u.OrganisationID = o.OrganisationID
WHERE	u.UserID = @intUserID
)


declare @csdate datetime

select @csdate = DateCreated from tblUserCourseStatus where UserID = @intUserID 
and CourseID =@intCourseID
order by DateCreated desc


declare @modss  table (moduleid int, dt datetime )


insert into   @modss
select m.moduleid, max(uqs.DateCreated) as dt
 from tblUserQuizStatus uqs
join tblModule m on m.ModuleID = uqs.ModuleID
where m.CourseID =@intCourseID and uqs.UserID = @intUserID and QuizStatusID =2
group by m.ModuleID


select @csdate as csdate
select * from @modss

declare @sendcert as bit

select @sendcert = case when MIN(dt)<@csdate then 0 else 1 end
from @modss




INSERT INTO @tblUserEndQuizInfo ( UserID, QuizID, PassMark, UnitID, ModuleID, QuizFrequency, QuizCompletionDate, NewQuizStatus, OldCourseStatus, NewCourseStatus, CourseID,sendcert)
VALUES (@intUserID, @intQuizID, @intPassMark, @intUnitID, @intModuleID, @intQuizFrequency,@dtmQuizCompletionDate,@intNewQuizStatus, @intOldCourseStatus, @intNewCourseStatus, @intCourseID,@sendcert)

SELECT * FROM @tblUserEndQuizInfo
END

GO





