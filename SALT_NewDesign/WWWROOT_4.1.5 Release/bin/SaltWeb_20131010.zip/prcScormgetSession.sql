
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcSCORMgetSession]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcSCORMgetSession]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[prcSCORMgetSession] (
             @StudentID int,
             @LessonID int,
            @isLesson bit  
           )  
AS
BEGIN
	SET NOCOUNT ON;
DECLARE @RC int
DECLARE @OrganisationID int
DECLARE @NumQuestions int
DECLARE @quizpassmark int
DECLARE @Name nvarchar(255)
SET @Name = N'Number_Of_Quiz_Questions'
SELECT @OrganisationID = OrganisationID FROM tblUser WHERE UserID = @StudentID
SELECT @quizpassmark = DefaultQuizPassMark FROM tblOrganisation WHERE OrganisationID = @organisationID 
--EXECUTE @NumQuestions = prcOrganisationConfig_GetOne  @organisationID = @OrganisationID, @name = @Name



If Exists (Select OrganisationID From tblOrganisationConfig Where OrganisationID = @organisationID And [Name]	= @Name)
Begin
	Select @NumQuestions = value from tblOrganisationConfig Where OrganisationID	= @OrganisationID And [Name]		= @Name 
End
Else
Begin
	Select @NumQuestions = Value From tblOrganisationConfig Where OrganisationID	is null And  [Name]		= @Name 
End



	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	DECLARE @initialized INT

	SELECT @initialized = Count(*) from tblScormDME
           WHERE UserID = @StudentID
           AND LessonID = @LessonID
           AND DME = 'cmi.core.student_id'  

   IF (@initialized = 0)
   BEGIN
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.student_id' ,'Salt�'+CAST(@StudentID AS varchar(20)))
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.student_name' ,(SELECT FirstName FROM tblUser WHERE UserID = @StudentID))
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.version' ,'3.4')
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.numrandom' ,@NumQuestions ) 
		INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.quizpassmark' ,@quizpassmark)
   END   
   if @isLesson = 1
   begin   
        Declare @LectoraBookmark nvarchar(100) 
        SELECT @LectoraBookmark = Q.lectoraBookmark from tblLesson L 
				inner join tblQuiz Q on L.ModuleID =  Q.ModuleID where L.Active = 1 and Q.Active = 1 and L.moduleID = @lessonID   
		SELECT DME,value FROM  tblScormDME
			   WHERE UserID = @StudentID
				and LessonID = @LessonID
				and DME <> 'salt.lessonorquiz'
				and DME <> 'salt.training.QuizURL2'
				and DME NOT LIKE 'cmi.interactions%'
		UNION SELECT 'salt.lessonorquiz' as DME, 'lesson' as [value]		
		UNION SELECT 'salt.training.QuizURL2' as DME, @LectoraBookmark as [value]
	end
	else
	begin
	    Declare @QuizBookmark varchar(1000)
		SELECT @QuizBookmark =   Q.lectoraBookmark from tblLesson L 
				inner join tblQuiz Q on L.ModuleID =  Q.ModuleID where L.Active = 1 and Q.Active = 1 and L.moduleID = @lessonID  		
		SELECT DME,value FROM  tblScormDME
				 WHERE UserID = @StudentID
					and LessonID = @LessonID
				and DME <> 'cmi.core.lesson_location'
				and DME <> 'salt.lessonorquiz'
				and DME NOT LIKE 'cmi.interactions%'				
		UNION SELECT 'cmi.core.lesson_location' AS DME, @QuizBookmark as [value]
		UNION SELECT 'salt.lessonorquiz' as DME, 'quiz' as [value]	
	end

END


GO


