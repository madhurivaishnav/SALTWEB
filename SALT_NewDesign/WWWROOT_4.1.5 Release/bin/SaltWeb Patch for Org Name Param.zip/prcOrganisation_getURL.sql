
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcOrganisation_GetURL]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcOrganisation_GetURL]
GO


CREATE procedure [dbo].[prcOrganisation_GetURL] @organisationID int
as 
begin
	
	declare @orgurl varchar(500)
	
	SELECT @orgurl =CASE WHEN 'true' = [Value] THEN 'HTTPS://' ELSE 'http://' END FROM tblAppConfig where Name = 'SSL' 
	SELECT organisationname, ORGURL =@orgurl + COALESCE(DOMAINNAME,'localhost')  + '/Restricted/Login.aspx' FROM tblOrganisation ORG WHERE ORG.OrganisationID =  @OrganisationID
	
	

END

GO


