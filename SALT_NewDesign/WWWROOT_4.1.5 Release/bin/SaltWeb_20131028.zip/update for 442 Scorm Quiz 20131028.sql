
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcSCORMgetSession]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcSCORMgetSession]
GO


/****** Object:  StoredProcedure [dbo].[prcSCORMgetSession]    Script Date: 10/28/2013 15:14:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[prcSCORMgetSession] (
             @StudentID int,
             @LessonID int,
            @isLesson bit  
           )  
AS
BEGIN
	SET NOCOUNT ON;
DECLARE @RC int
DECLARE @OrganisationID int
DECLARE @NumQuestions int
DECLARE @quizpassmark int
DECLARE @Name nvarchar(255)
SET @Name = N'Number_Of_Quiz_Questions'
SELECT @OrganisationID = OrganisationID FROM tblUser WHERE UserID = @StudentID
SELECT @quizpassmark = DefaultQuizPassMark FROM tblOrganisation WHERE OrganisationID = @organisationID 
--EXECUTE @NumQuestions = prcOrganisationConfig_GetOne  @organisationID = @OrganisationID, @name = @Name



If Exists (Select OrganisationID From tblOrganisationConfig Where OrganisationID = @organisationID And [Name]	= @Name)
Begin
	Select @NumQuestions = value from tblOrganisationConfig Where OrganisationID	= @OrganisationID And [Name]		= @Name 
End
Else
Begin
	Select @NumQuestions = Value From tblOrganisationConfig Where OrganisationID	is null And  [Name]		= @Name 
End


	-- delete then insert these as we dont want duplicates
	delete from tblScormDME 
	where UserID  =@StudentID and LessonID =@LessonID
	and DME in ('cmi.core.student_id','cmi.core.student_name','cmi.core.version','cmi.core.numrandom','cmi.core.quizpassmark','salt.lessonorquiz','salt.training.QuizURL2')
	and DME NOT LIKE 'cmi.interactions%'
		

	INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.student_id' ,'Salt�'+CAST(@StudentID AS varchar(20)))
	INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.student_name' ,(SELECT FirstName FROM tblUser WHERE UserID = @StudentID))
	INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.version' ,'3.4')
	INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.numrandom' ,@NumQuestions ) 
	INSERT INTO  tblScormDME (UserID,LessonID,DME,[value]) VALUES(@StudentID,@LessonID,'cmi.core.quizpassmark' ,@quizpassmark)

   if @isLesson = 1
   begin   
		-- quiz bookmark
        Declare @LectoraBookmark nvarchar(100) 
        SELECT @LectoraBookmark = Q.lectoraBookmark from tblLesson L 
				inner join tblQuiz Q on L.ModuleID =  Q.ModuleID where L.Active = 1 and Q.Active = 1 and L.moduleID = @lessonID   
				
		SELECT DME,value FROM  tblScormDME
			   WHERE UserID = @StudentID
				and LessonID = @LessonID
		UNION SELECT 'salt.lessonorquiz' as DME, 'lesson' as [value]		
		UNION SELECT 'salt.training.QuizURL2' as DME, @LectoraBookmark as [value]
		
	end
	else
	begin
		
		-- delete the existing quiz dmes
		delete from tblScormDME 
		where UserID  =@StudentID and LessonID =@LessonID
		and DME in ('cmi.suspend_data','cmi.core.lesson_location')
						
		
	    Declare @QuizBookmark varchar(1000)
		SELECT @QuizBookmark =   Q.lectoraBookmark from tblLesson L 
				inner join tblQuiz Q on L.ModuleID =  Q.ModuleID where L.Active = 1 and Q.Active = 1 and L.moduleID = @lessonID  		
		SELECT DME,value FROM  tblScormDME
				 WHERE UserID = @StudentID
					and LessonID = @LessonID				
		UNION SELECT 'cmi.core.lesson_location' AS DME, @QuizBookmark as [value]
		UNION SELECT 'salt.lessonorquiz' as DME, 'quiz' as [value]	
	end

END



GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcSCORMgetValue]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcSCORMgetValue]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[prcSCORMgetValue] (
             @StudentID int,
             @LessonID int,
             @DME  varchar(50)
           )  
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
if @DME='cmi.core.lesson_location'
begin
		SELECT  Q.lectoraBookmark from tblLesson L 
		inner join tblQuiz Q on L.ModuleID =  Q.ModuleID where L.Active = 1 and Q.Active = 1 and L.lessonID = @lessonID
end
else
begin
	if not exists(	SELECT [value] FROM  tblScormDME WHERE UserID = @StudentID and LessonID = @LessonID and DME = @DME)
	begin 
		select ''
	end
	else
	begin 
		SELECT [value] FROM  tblScormDME
		WHERE UserID = @StudentID
		and LessonID = @LessonID
		and DME = @DME
	end
end
END



GO



