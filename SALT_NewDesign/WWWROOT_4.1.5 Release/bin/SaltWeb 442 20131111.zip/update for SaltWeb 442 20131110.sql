IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcQuizSession_GetEndQuizInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcQuizSession_GetEndQuizInfo]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*Summary:
read all information needed to end a quiz

Returns:
data table

Called By:
ToolBook.cs: GetEndQuizInfo

Remarks:

QuizStatusID Status
------------ --------------------------------------------------
0            Unassigned
1            Not Started
2            Passed
3            Failed
4            Expired (Time Elapsed)
5            Expired (New Content)

Author: Li Zhang
Date Created: 13-10-2006
Modification History
-----------------------------------------------------------
v#	Author		Date			Description
#1	mikev		1/5/2007		Added LessonCompletionDate
**/

CREATE PROCEDURE [dbo].[prcQuizSession_GetEndQuizInfo]
(
@quizSessionID varchar(50) -- unique that identifies this toolbook quiz session
, @duration int -- time used to complete the quiz
, @score int -- user quiz score
)
AS
SET nocount on
BEGIN
DECLARE @intUserID	int	-- user id
,		@intQuizID	int -- quiz id
,		@intPassMark	int	-- quiz pass mark
,		@intUnitID	int	-- user's unit id
,		@intModuleID	int -- quiz module id
,		@intCourseID	int -- module course id
,		@intOldCourseStatus	int -- course status before update
,		@intNewQuizStatus int -- the quiz status
, 		@intNewCourseStatus	int	-- course status after update
,		@intQuizFrequency int
,		@dtmQuizCompletionDate datetime
DECLARE	@tblUserEndQuizInfo table	-- return table with all details needed to end a quiz
(
UserID	int
, QuizID int
, PassMark int
, UnitID int
, ModuleID int
, QuizFrequency int
, QuizCompletionDate datetime
, NewQuizStatus int
, OldCourseStatus int
, NewCourseStatus int
, CourseID int
, sendcert bit

)

--< read required data >--

SET @intUserID = dbo.udfGetUserIDBySessionID(@quizSessionID)
SET @intQuizID = dbo.udfGetQuizIDBySessionID(@quizSessionID)
SELECT @intUnitID = (SELECT TOP 1 UnitID FROM tblUser WHERE UserID = @intUserID)
SELECT @intModuleID = (SELECT TOP 1 ModuleID FROM tblQuiz WHERE QuizID = @intQuizID)
SET @intPassMark = dbo.udfQuiz_GetPassMark(@intUnitID, @intModuleID)
IF @score < @intPassMark
BEGIN
--< Quiz status: failed >--
SET @intNewQuizStatus = 3
END
IF @score > @intPassMark OR @score = @intPassMark
BEGIN
--< Quiz status: passed >--
SET @intNewQuizStatus = 2
END

SELECT @intCourseID = (SELECT TOP 1 CourseID FROM tblModule WHERE ModuleID = @intModuleID)
EXEC @intOldCourseStatus = prcUserCourseStatus_GetStatus @intCourseID, @intUserID
EXEC @intNewCourseStatus = prcUserCourseStatus_Calc @intCourseID, @intUserID,  @intNewQuizStatus,@intModuleID

--< get pre-defined quiz frequency from tblUnitRule >--
--< if the value is null then use the default quiz frequency in tblOrganisation >--

-- mikev(1): added QuizCompletionDate
SET @intQuizFrequency = (
SELECT  TOP 1   ISNULL(ur.QuizFrequency, o.DefaultQuizFrequency)
FROM   	tblUnitRule AS ur INNER JOIN tblUser AS u
ON ur.UnitID = u.UnitID
INNER JOIN tblOrganisation AS o ON u.OrganisationID = o.OrganisationID
WHERE	u.UserID = @intUserID
)

SET @dtmQuizCompletionDate = (
SELECT  TOP 1	ISNULL(ur.QuizCompletionDate, o.DefaultQuizCompletionDate)
FROM   	tblUnitRule AS ur INNER JOIN tblUser AS u
ON ur.UnitID = u.UnitID
INNER JOIN tblOrganisation AS o ON u.OrganisationID = o.OrganisationID
WHERE	u.UserID = @intUserID
)

INSERT INTO @tblUserEndQuizInfo ( UserID, QuizID, PassMark, UnitID, ModuleID, QuizFrequency, QuizCompletionDate, NewQuizStatus, OldCourseStatus, NewCourseStatus, CourseID)
VALUES (@intUserID, @intQuizID, @intPassMark, @intUnitID, @intModuleID, @intQuizFrequency,@dtmQuizCompletionDate,@intNewQuizStatus, @intOldCourseStatus, @intNewCourseStatus, @intCourseID)

SELECT * FROM @tblUserEndQuizInfo
END


GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcQuizSession_GetEndQuizInfo2]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcQuizSession_GetEndQuizInfo2]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




/*Summary:
read all information needed to end a quiz

Returns:
data table

Called By:
ToolBook.cs: GetEndQuizInfo

Remarks:

QuizStatusID Status
------------ --------------------------------------------------
0            Unassigned
1            Not Started
2            Passed
3            Failed
4            Expired (Time Elapsed)
5            Expired (New Content)

Author: Li Zhang
Date Created: 13-10-2006
Modification History
-----------------------------------------------------------
v#	Author		Date			Description
#1	mikev		1/5/2007		Added LessonCompletionDate
**/

CREATE PROCEDURE [dbo].[prcQuizSession_GetEndQuizInfo2]
(
@intUserID int -- student must only sit one quiz at a time for a module
,@intModuleID int
, @duration int -- time used to complete the quiz
, @score int -- user quiz score
)
AS
SET nocount on
BEGIN
DECLARE 
		@intQuizID	int -- quiz id
,		@intPassMark	int	-- quiz pass mark
,		@intUnitID	int	-- user's unit id
,		@intCourseID	int -- module course id
,		@intOldCourseStatus	int -- course status before update
,		@intNewQuizStatus int -- the quiz status
, 		@intNewCourseStatus	int	-- course status after update
,		@intQuizFrequency int
,		@dtmQuizCompletionDate datetime
DECLARE	@tblUserEndQuizInfo table	-- return table with all details needed to end a quiz
(
UserID	int
, QuizID int
, PassMark int
, UnitID int
, ModuleID int
, QuizFrequency int
, QuizCompletionDate datetime
, NewQuizStatus int
, OldCourseStatus int
, NewCourseStatus int
, CourseID int
, SessionID varchar(50)
, sendcert bit

)

--< read required data >--
DECLARE @quizSessionID varchar(50)
SELECT @quizSessionID =  (SELECT top 1 quizSessionID
  FROM tblQuiz Q
inner join tblQuizSession QS on  Q.QuizID = QS.QuizID 
WHERE Q.Active = 1 AND QS.DateTimeStarted IS NOT NULL
AND QS.DateTimeCompleted IS NULL
AND Q.ModuleID = @intModuleID
AND QS.UserID = @intUserID
order by DateTimeStarted desc)


select  @intQuizID = quizid from 
tblQuiz where ModuleID =@intModuleID





if @quizSessionID is null   begin
	set @quizSessionID = newid()
	
	Insert Into
	tblQuizSession
	(
	QuizSessionID,
	UserID,
	QuizID,
	DateTimeStarted
	)
	Values
	(
	@quizSessionID,
	@intUserID,
	@intQuizID,
	GETUTCDATE()
)

	
end 

							

SELECT @intUnitID = (SELECT TOP 1 UnitID FROM tblUser WHERE UserID = @intUserID)
--SELECT @intModuleID = (SELECT TOP 1 ModuleID FROM tblQuiz WHERE QuizID = @intQuizID)
SET @intPassMark = dbo.udfQuiz_GetPassMark(@intUnitID, @intModuleID)
IF @score < @intPassMark
BEGIN
--< Quiz status: failed >--
SET @intNewQuizStatus = 3
END
IF @score > @intPassMark OR @score = @intPassMark
BEGIN
--< Quiz status: passed >--
SET @intNewQuizStatus = 2
END

SELECT @intCourseID = (SELECT TOP 1 CourseID FROM tblModule WHERE ModuleID = @intModuleID)
EXEC @intOldCourseStatus = prcUserCourseStatus_GetStatus @intCourseID, @intUserID
EXEC @intNewCourseStatus = prcUserCourseStatus_Calc @intCourseID, @intUserID,  @intNewQuizStatus,@intModuleID

--< get pre-defined quiz frequency from tblUnitRule >--
--< if the value is null then use the default quiz frequency in tblOrganisation >--

-- mikev(1): added QuizCompletionDate
SET @intQuizFrequency = (
SELECT  TOP 1   ISNULL(ur.QuizFrequency, o.DefaultQuizFrequency)
FROM   	tblUnitRule AS ur INNER JOIN tblUser AS u
ON ur.UnitID = u.UnitID
INNER JOIN tblOrganisation AS o ON u.OrganisationID = o.OrganisationID
WHERE	u.UserID = @intUserID
)

SET @dtmQuizCompletionDate = (
SELECT  TOP 1	ISNULL(ur.QuizCompletionDate, o.DefaultQuizCompletionDate)
FROM   	tblUnitRule AS ur INNER JOIN tblUser AS u
ON ur.UnitID = u.UnitID
INNER JOIN tblOrganisation AS o ON u.OrganisationID = o.OrganisationID
WHERE	u.UserID = @intUserID
)

INSERT INTO @tblUserEndQuizInfo ( UserID, QuizID, PassMark, UnitID, ModuleID, QuizFrequency, QuizCompletionDate, NewQuizStatus, OldCourseStatus, NewCourseStatus, CourseID, SessionID)
VALUES (@intUserID, @intQuizID, @intPassMark, @intUnitID, @intModuleID, @intQuizFrequency,@dtmQuizCompletionDate,@intNewQuizStatus, @intOldCourseStatus, @intNewCourseStatus, @intCourseID,@quizSessionID)

SELECT * FROM @tblUserEndQuizInfo
END




GO




IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcQuizSession_UpdateEndQuizInfo]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcQuizSession_UpdateEndQuizInfo]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[prcQuizSession_UpdateEndQuizInfo]
(
@QuizSessionID	varchar(50) -- unique GUID that identifies this toolbook quiz session
, @Duration	int -- the duration in seconds of the quiz as mesured by toolbook
, @Score 	int -- the score as mesured by toolbook
, @UserID	int	-- user id
, @QuizID	int -- quiz id
, @PassMark	int	-- quiz pass mark
, @UnitID	int	-- user's unit id
, @ModuleID	int -- quiz module id
, @CourseID	int -- module course id
, @OldCourseStatus	int -- course status before update
, @NewQuizStatus int -- the quiz status
, @NewCourseStatus	int	-- course status after update
, @QuizFrequency	int -- quiz frequency
, @QuizCompletionDate	datetime -- quiz completiondate
)
AS
SET nocount on
SET xact_abort on
BEGIN TRANSACTION

declare @createrec as bit
set @createrec = 0


declare @OrgID int
select @OrgID = organisationID from tblUnit where tblUnit.UnitID=@UnitID

set @QuizCompletionDate = dbo.udfDaylightSavingTimeToUTC(@QuizCompletionDate, @OrgID)

DECLARE @dateCreated datetime
SET @dateCreated = GETUTCDATE()

IF EXISTS
(
SELECT QuizSessionID
FROM tblQuizSession
WHERE QuizSessionID = @QuizSessionID
AND	DateTimeStarted IS NOT NULL
AND DateTimeCompleted IS NULL
)
BEGIN
	-- < update tblQuizSession >--
	UPDATE tblQuizSession
	SET DateTimeCompleted = @dateCreated
	, Duration = DATEDIFF(second,DateTimeStarted,@dateCreated)
	, QuizScore = @Score
	, QuizPassMark = @PassMark
	WHERE
	QuizSessionID = @QuizSessionID

	--< insert into tblUserQuizStatus >--
	INSERT INTO
	tblUserQuizStatus
	(
	UserID,
	ModuleID,
	QuizStatusID,
	QuizFrequency,
	QuizPassMark,
	QuizCompletionDate,
	QuizScore,
	QuizSessionID,
	DateCreated
	)
	VALUES
	(
	@UserID,
	@ModuleID,
	@NewQuizStatus,
	@QuizFrequency,
	@PassMark,
	@QuizCompletionDate,
	@Score,
	@QuizSessionID,
	@dateCreated
	)

	--< insert into tblUserCourseStatus >--

	-- if the user redo the quiz when they are still having a completed user course status
	-- check if the last 2 course status is a completed status
	-- if it is then we update the date of the last course status id to avoid new rows being inserted
	-- if not we just add a new row
	IF (@OldCourseStatus=2 and @OldCourseStatus = @NewCourseStatus)
	BEGIN
		
		declare @csdate datetime
		
		
		select top 1 @csdate = DateCreated 
		from tblUserCourseStatus 
		where UserID = @UserID 	and CourseID =@CourseID
		order by DateCreated desc

		declare @modss  table (moduleid int, dt datetime )

		insert into   @modss
		select m.moduleid, max(uqs.DateCreated) as dt
		 from tblUserQuizStatus uqs
		join tblModule m on m.ModuleID = uqs.ModuleID
		where m.CourseID =@CourseID and uqs.UserID = @UserID and QuizStatusID =2
		group by m.ModuleID

		select @createrec = case when MIN(dt)>@csdate then 1 else 0 end
		from @modss

		if(@createrec =1)
		begin
			EXEC prcUserCourseStatus_Insert @UserID, @ModuleID, @NewCourseStatus
		end

	END
	ELSE IF (@OldCourseStatus = -1) or (@OldCourseStatus <> @NewCourseStatus)	
	BEGIN
	
		if(@NewCourseStatus=2) begin
			set @createrec =1
		end
		
		EXEC prcUserCourseStatus_Insert @UserID, @ModuleID, @NewCourseStatus
	END
	ELSE BEGIN
		IF NOT EXISTS (SELECT UserID FROM vwUserModuleAccess where UserID = @UserID AND CourseID = @CourseID) AND
		EXISTS (SELECT UserCourseStatusID FROM tblUserCourseStatus WHERE UserID = @UserID AND CourseID = @CourseID AND CourseStatusID <> 0)
		BEGIN
			EXEC prcUserCourseStatus_Insert @UserID, @ModuleID,  0
		END
	END

END


COMMIT TRANSACTION

select @createrec as sendcert 
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcReport_GetNextOnceOnlyReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcReport_GetNextOnceOnlyReport]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[prcReport_GetNextOnceOnlyReport]

AS
BEGIN
-- NextRun is saved in the ORGs timezone so that when an ORG goes into daylight saving the Report is run at the correct time.
-- ALL other times are saved in the ORGs timezone to reduce load on the GUI when the ORGs timezone is changed
-- NextRun is never null
SET NOCOUNT ON
DECLARE @ScheduleID int,
@RunDate datetime,
@ReportStartDate datetime,
@ReportFrequencyPeriod char(1),
@ReportFrequency int,
@OrgID int	,
@ReportFromDate datetime,
@ReportPeriodType int,
@NumberDelivered int,
@ReportID int,
@DateFrom DateTime
SELECT @ScheduleID = ScheduleID
FROM tblReportSchedule
INNER JOIN tblReportInterface ON tblReportSchedule.ReportID = tblReportInterface.ReportID
INNER JOIN tblUser ON tblReportSchedule.UserID = tblUser.UserID  AND tblUser.Active = 1
INNER JOIN tblOrganisation ON tblOrganisation.OrganisationID = tblReportSchedule.ParamOrganisationID
WHERE  CourseStatusLastUpdated > dbo.udfGetSaltOrgMidnight(tblUser.OrganisationID)
AND (NextRun <= dbo.udfUTCtoDaylightSavingTime(GETUTCDATE(),tblReportSchedule.ParamOrganisationID))
AND (TerminatedNormally = 0)
AND (IsPeriodic = 'O')


DECLARE @OnBehalfOf nvarchar(255)
DECLARE @ReplyTo nvarchar(255)
DECLARE @FromDate DateTime = CAST('1 Jan 2002' as datetime)

IF (@ScheduleID IS NOT NULL)
BEGIN
DECLARE @NextRun datetime
SELECT @NextRun = NextRun,
@ReportStartDate = ReportStartDate,
@ReportFrequencyPeriod = ReportFrequencyPeriod,
@ReportFrequency = ReportFrequency,
@OrgID = ParamOrganisationID,
@ReportFromDate = ReportFromDate,
@NumberDelivered = NumberDelivered,
@ReportPeriodType = coalesce(ReportPeriodType ,3),
@ReportID = ReportID,
@DateFrom = ParamDateFrom
FROM tblReportSchedule WHERE ScheduleID = @ScheduleID

SET @RunDate = @NextRun


SET @NextRun = dbo.udfReportSchedule_IncrementNextRunDate -- get the new NexrRun value
(
@RunDate ,
@ReportStartDate ,
@ReportFrequencyPeriod ,
@ReportFrequency ,
@OrgID
)



-- update the Report Schedule
UPDATE tblReportSchedule -- Move NextRun,Lastrun forward by one period
SET NumberDelivered = NumberDelivered + 1,
TerminatedNormally = 1,
NextRun = cast('1 jan 2050' as datetime),
LastRun = @RunDate,
LastUpdatedBy=0,
Lastupdated=getUTCdate()

WHERE ScheduleID = @ScheduleID

-- get the Report period (we know the 'to' date - just need to calculate the 'from' date)
IF ((@ReportPeriodType <> 2) AND (@ReportPeriodType <> 3))
BEGIN
SET @FromDate = CAST('1 Jan 2002' as datetime)
END

IF (@ReportPeriodType = 3)
BEGIN
SET @FromDate = @ReportFromDate
END

IF (@ReportPeriodType = 2)
BEGIN
SET @FromDate =
CASE
WHEN (@ReportFrequencyPeriod='Y') THEN DATEADD(YEAR,-@ReportFrequency,@RunDate)
WHEN (@ReportFrequencyPeriod='M') THEN DATEADD(MONTH,-@ReportFrequency,@RunDate)
WHEN (@ReportFrequencyPeriod='W') THEN DATEADD(WEEK,-@ReportFrequency,@RunDate)
WHEN (@ReportFrequencyPeriod='D') THEN DATEADD(DAY,-@ReportFrequency,@RunDate)
WHEN (@ReportFrequencyPeriod='H') THEN DATEADD(HOUR,-@ReportFrequency,@RunDate)
END

END

IF (@ReportID=10) OR (@ReportID=22) OR (@ReportID=23) OR (@ReportID=24)
BEGIN
SET @FromDate = @DateFrom
END

SELECT @OnBehalfOf = dbo.udfGetEmailOnBehalfOf (0)
END -- IF ScheduleID is not null


-- return the results
SET NOCOUNT OFF
SELECT TOP (1) [ScheduleID]
,RS.UserID
,RS.ReportID
,[LastRun]
,[ReportStartDate]
,[ReportFrequency]
,[ReportFrequencyPeriod]
,[DocumentType]
,[ParamOrganisationID]
,[ParamCompleted]
,[ParamStatus]
,[ParamFailCount]
,[ParamCourseIDs]
,[ParamHistoricCourseIDs]
,[ParamAllUnits]
,[ParamTimeExpired]
,[ParamTimeExpiredPeriod]
,[ParamQuizStatus]
,[ParamGroupBy]
,[ParamGroupingOption]
,[ParamFirstName]
,[ParamLastName]
,[ParamUserName]
,[ParamEmail]
,[ParamIncludeInactive]
,[ParamSubject]
,[ParamBody]
,[ParamProfileID]
,[ParamProfilePeriodID]
,[ParamPolicyIDs]
,[ParamAcceptance]
,[ParamOnlyUsersWithShortfall]
,[ParamEffectiveDate]
,[ParamSortBy]
,[ParamClassificationID]
,ParamLangInterfaceName
, case
when tblReportinterface.ReportID = 26 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.2'))
when tblReportinterface.ReportID = 27 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.2'))
when tblReportinterface.ReportID = 3 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.1'))
when tblReportinterface.ReportID = 6 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.1'))
when (tblReportinterface.ReportID = 22) or (tblReportinterface.ReportID = 23) or (tblReportinterface.ReportID = 24) or (tblReportinterface.ReportID = 10)
then
(
select coalesce(LangEntryValue, (select coalesce(tblLangValue.LangEntryValue,'Missing Localisation') FROM tblLangValue where tblLang.LangID = tblLangValue.LangID   AND (tblLangValue.Active = 1) and tblLangValue.LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = 'Report.Summary') and tblLangValue.LangResourceID = tblLangResource.LangResourceID))
)

else coalesce(tblLangValue.LangEntryValue,'Missing Localisation')
end as ReportName
,tblReportInterface.RDLname
,tblUser.FirstName
,tblUser.LastName
,tblUser.Email
,ParamUnitIDs
,paramOrganisationID
,RS.ParamLangCode
,ParamLangCode
,ParamLicensingPeriod
,RS.ReportEndDate
,RS.ReportTitle
,RS.NumberOfReports
,RS.ReportFromDate
,(dbo.udfGetCCList(RS.ScheduleID)) as CCList
,RS.ReportPeriodType
,dbo.udfGetEmailOnBehalfOf (ParamOrganisationID) as OnBehalfOf
,RS.NextRun
,RS.ReportFromDate
,@FromDate as FromDate
,dbo.udfGetEmailReplyTo (ParamOrganisationID,tblUser.FirstName + ' ' + tblUser.LastName + ' <' + tblUser.Email + '>') as ReplyTo
,CASE when exists (SELECT Value FROM  tblAppConfig WHERE (Name = 'SEND_AUTO_EMAILS') AND (UPPER(Value) = 'YES')) then 0 ELSE 1 END as StopEmails
,CAST(convert( varchar(11), dbo.udfUTCtoDaylightSavingTime(DATEADD(d,1,GETUTCDATE()),@OrgID),113) AS DateTime) as Tomorrow
,CASE when tblUser.usertypeid=4 then dbo.udfUser_GetAdministratorsEmailAddress (tblUser.UserID) else tblUser.Email end as SenderEmail
,IsPeriodic
FROM
tblReportinterface
inner join tblReportSchedule RS  on tblReportinterface.ReportID = RS.ReportID
INNER JOIN tblUser ON RS.UserID = tblUser.UserID
LEFT OUTER JOIN tblLang ON tblLang.LangCode = RS.ParamLangCode
LEFT OUTER JOIN tblLangInterface ON  paramlanginterfacename = tblLangInterface.langinterfacename
LEFT OUTER JOIN tblLangResource ON  tblLangResource.langresourcename = 'rptreporttitle'
LEFT OUTER JOIN tblLangValue ON tblLang.LangID = tblLangValue.LangID   AND (tblLangValue.Active = 1) and tblLangValue.LangInterfaceID = tblLangInterface.LangInterfaceID and tblLangValue.LangResourceID = tblLangResource.LangResourceID

WHERE ScheduleID = @ScheduleID


END

GO





IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcReport_GetNextReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcReport_GetNextReport]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[prcReport_GetNextReport]

AS
BEGIN
-- NextRun is saved in the ORGs timezone so that when an ORG goes into daylight saving the Report is run at the correct time.
-- ALL other times are saved in the ORGs timezone to reduce load on the GUI when the ORGs timezone is changed

UPDATE tblReportSchedule -- fix schedules that have been modified by GUI
SET TerminatedNormally = 1
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
WHERE (TerminatedNormally = 0)
AND (IsPeriodic = 'M')
AND ReportEndDate IS NULL -- flag to indicate that NumberOfReports is being used
AND NumberOfReports IS NOT NULL
AND NumberDelivered >= NumberOfReports
)

UPDATE tblReportSchedule -- fix schedules that have been modified by GUI
SET TerminatedNormally = 0
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
WHERE (TerminatedNormally = 1)
AND (IsPeriodic = 'M')
AND ReportEndDate IS NULL -- flag to indicate that NumberOfReports is being used
AND NumberOfReports IS NOT NULL
AND NumberDelivered < NumberOfReports
)



UPDATE tblReportSchedule -- fix schedules that have been modified by GUI
SET
LastRun = '1 Jan 1997',
NextRun = dbo.udfReportSchedule_CalcNextRunDate
(
ReportStartDate,
ReportStartDate ,
ReportFrequencyPeriod ,
ReportFrequency ,
ParamOrganisationID
)
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
INNER JOIN tblUser ON tblReportSchedule.UserID = tblUser.UserID
WHERE (TerminatedNormally = 0)
AND (IsPeriodic != 'N')
AND (tblUser.Active = 1)
AND LASTRUN IS NULL
AND NEXTRUN IS NULL
)


UPDATE tblReportSchedule -- fix schedules that have been modified by GUI
SET LastRun = '1 Jan 2001'
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
INNER JOIN tblUser ON tblReportSchedule.UserID = tblUser.UserID
WHERE (TerminatedNormally = 0)
AND (IsPeriodic != 'N')
AND (tblUser.Active = 1)
AND LASTRUN IS NULL
)


UPDATE tblReportSchedule -- fix schedules that have been modified by GUI
SET NextRun = dbo.udfReportSchedule_CalcNextRunDate
(
LastRun ,
ReportStartDate ,
ReportFrequencyPeriod ,
ReportFrequency ,
ParamOrganisationID
)
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
INNER JOIN tblUser ON tblReportSchedule.UserID = tblUser.UserID
--WHERE (TerminatedNormally = 0)
AND (IsPeriodic != 'N')
AND (tblUser.Active = 1)
AND NEXTRUN IS NULL
)

UPDATE tblReportSchedule -- fix schedules that have been modified by GUI
SET TerminatedNormally = 1
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
WHERE (TerminatedNormally = 0)
AND (IsPeriodic = 'M')
AND ReportEndDate IS NOT NULL
AND NextRun > ReportEndDate
AND NumberOfReports IS NULL
)

UPDATE tblReportSchedule -- fix schedules that have been modified by GUI
SET TerminatedNormally = 0
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
WHERE (TerminatedNormally = 1)
AND (IsPeriodic = 'M')
AND ReportEndDate IS NOT NULL
AND NextRun <= ReportEndDate
AND NumberOfReports IS NULL
)

UPDATE tblReportSchedule -- fix schedules that have been modified by GUI
SET TerminatedNormally = 0
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
WHERE (TerminatedNormally = 1)
AND (IsPeriodic = 'M')
AND ReportEndDate IS NULL
AND NumberOfReports IS  NULL
)


-- NextRun is never null
SET NOCOUNT ON
DECLARE @ScheduleID int,
@RunDate datetime,
@ReportStartDate datetime,
@ReportFrequencyPeriod char(1),
@ReportFrequency int,
@OrgID int	,
@ReportFromDate datetime,
@NumberDelivered int,
@NumberOfReports int,
@ReportEndDate datetime,
@ReportPeriodType int,
@ReportID int

SELECT @ScheduleID =  ScheduleID
FROM tblReportSchedule
INNER JOIN tblReportInterface ON tblReportSchedule.ReportID = tblReportInterface.ReportID
INNER JOIN tblUser ON tblReportSchedule.UserID = tblUser.UserID AND tblUser.Active = 1
INNER JOIN tblOrganisation ON tblOrganisation.OrganisationID = tblReportSchedule.ParamOrganisationID
WHERE  CourseStatusLastUpdated > dbo.udfGetSaltOrgMidnight(tblUser.OrganisationID)
AND (NextRun <= dbo.udfUTCtoDaylightSavingTime(GETUTCDATE(),tblReportSchedule.ParamOrganisationID))
AND (TerminatedNormally = 0)
AND (IsPeriodic = 'M')


DECLARE @OnBehalfOf nvarchar(255)
DECLARE @ReplyTo nvarchar(255)
DECLARE @FromDate DateTime = CAST('1 Jan 1997' as datetime)
DECLARE @DateFrom DateTime

IF (@ScheduleID IS NOT NULL)
BEGIN
DECLARE @NextRun datetime
SELECT @NextRun = NextRun,
@ReportStartDate = ReportStartDate,
@ReportFrequencyPeriod = ReportFrequencyPeriod,
@ReportFrequency = ReportFrequency,
@OrgID = ParamOrganisationID,
@ReportFromDate = ReportFromDate,
@NumberDelivered = NumberDelivered,
@NumberOfReports = NumberOfReports,
@ReportEndDate = ReportEndDate ,
@ReportPeriodType = coalesce(ReportPeriodType ,3),
@ReportID = ReportID,
@DateFrom = ParamDateFrom
FROM tblReportSchedule WHERE ScheduleID = @ScheduleID

SET @RunDate = dbo.udfReportSchedule_CalcNextRunDate -- may have missed a couple of reports if the server was down so just verify that NEXTRUN makes sense
(
@NextRun,
@ReportStartDate ,
@ReportFrequencyPeriod,
@ReportFrequency,
@OrgID
)

SET @NextRun = dbo.udfReportSchedule_IncrementNextRunDate -- get the new NexrRun value
(
@RunDate ,
@ReportStartDate ,
@ReportFrequencyPeriod ,
@ReportFrequency ,
@OrgID
)
-- now look for termination conditions
DECLARE @TerminatedNormally bit = 0

IF  @ReportEndDate IS NOT NULL AND (@ReportEndDate < @NextRun) BEGIN SET @TerminatedNormally = 1  END
IF @NumberOfReports IS NOT NULL AND (@NumberOfReports < (@NumberDelivered + 1)) BEGIN SET @TerminatedNormally = 1  END

-- update the Report Schedule
UPDATE tblReportSchedule -- Move NextRun,Lastrun forward by one period
SET NumberDelivered = NumberDelivered + 1,
TerminatedNormally = @TerminatedNormally,
LastRun = @RunDate,
NextRun = @NextRun,
LastUpdatedBy=0,
Lastupdated=getUTCdate()
WHERE ScheduleID = @ScheduleID

-- get the Report period (we know the 'to' date - just need to calculate the 'from' date)

IF ((@ReportPeriodType <> 2) AND (@ReportPeriodType <> 3))
BEGIN
SET @FromDate = CAST('1 Jan 1997' as datetime)
END

IF (@ReportPeriodType = 3)
BEGIN
SELECT @FromDate = @ReportFromDate
END

IF (@ReportPeriodType = 2)
BEGIN
SET @FromDate =
CASE
WHEN (@ReportFrequencyPeriod='Y') THEN DATEADD(YEAR,-@ReportFrequency,@RunDate)
WHEN (@ReportFrequencyPeriod='M') THEN DATEADD(MONTH,-@ReportFrequency,@RunDate)
WHEN (@ReportFrequencyPeriod='W') THEN DATEADD(WEEK,-@ReportFrequency,@RunDate)
WHEN (@ReportFrequencyPeriod='D') THEN DATEADD(DAY,-@ReportFrequency,@RunDate)
WHEN (@ReportFrequencyPeriod='H') THEN DATEADD(HOUR,-@ReportFrequency,@RunDate)
END
END
IF (@ReportID=10) OR (@ReportID=22) OR (@ReportID=23) OR (@ReportID=24)
BEGIN
SET @FromDate = @DateFrom
END

SELECT @OnBehalfOf = dbo.udfGetEmailOnBehalfOf (@OrgID)
END -- IF ScheduleID is not null


-- return the results
SET NOCOUNT OFF
SELECT TOP (1) [ScheduleID]
,RS.UserID
,RS.ReportID
,[LastRun]
,[ReportStartDate]
,[ReportFrequency]
,[ReportFrequencyPeriod]
,[DocumentType]
,[ParamOrganisationID]
,[ParamCompleted]
,[ParamStatus]
,[ParamFailCount]
,[ParamCourseIDs]
,[ParamHistoricCourseIDs]
,[ParamAllUnits]
,[ParamTimeExpired]
,[ParamTimeExpiredPeriod]
,[ParamQuizStatus]
,[ParamGroupBy]
,[ParamGroupingOption]
,[ParamFirstName]
,[ParamLastName]
,[ParamUserName]
,[ParamEmail]
,[ParamIncludeInactive]
,[ParamSubject]
,[ParamBody]
,[ParamProfileID]
,[ParamProfilePeriodID]
,[ParamPolicyIDs]
,[ParamAcceptance]
,[ParamOnlyUsersWithShortfall]
,[ParamEffectiveDate]
,[ParamSortBy]
,[ParamClassificationID]
,ParamLangInterfaceName
, case
when tblReportinterface.ReportID = 26 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.2'))
when tblReportinterface.ReportID = 27 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.2'))
when tblReportinterface.ReportID = 3 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.1'))
when tblReportinterface.ReportID = 6 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.1'))
when (tblReportinterface.ReportID = 22) or (tblReportinterface.ReportID = 23) or (tblReportinterface.ReportID = 24) or (tblReportinterface.ReportID = 10)
then
(
select coalesce(LangEntryValue, (select coalesce(tblLangValue.LangEntryValue,'Missing Localisation') FROM tblLangValue where tblLang.LangID = tblLangValue.LangID   AND (tblLangValue.Active = 1) and tblLangValue.LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = 'Report.Summary') and tblLangValue.LangResourceID = tblLangResource.LangResourceID))
)

else coalesce(tblLangValue.LangEntryValue,'Missing Localisation')
end as ReportName
,tblReportInterface.RDLname
,tblUser.FirstName
,tblUser.LastName
,tblUser.Email
,ParamUnitIDs
,paramOrganisationID
,RS.ParamLangCode
,ParamLangCode
,ParamLicensingPeriod
,RS.ReportEndDate
,RS.ReportTitle
,RS.NumberOfReports
,RS.ReportFromDate
,(dbo.udfGetCCList(RS.ScheduleID)) as CCList
,RS.ReportPeriodType
,dbo.udfGetEmailOnBehalfOf (ParamOrganisationID) as OnBehalfOf
,RS.NextRun
,@FromDate as FromDate
,dbo.udfGetEmailReplyTo (ParamOrganisationID,tblUser.FirstName + ' ' + tblUser.LastName + ' <' + tblUser.Email + '>') as ReplyTo
,CASE when exists (SELECT Value FROM  tblAppConfig WHERE (Name = 'SEND_AUTO_EMAILS') AND (UPPER(Value) = 'YES')) then 0 ELSE 1 END as StopEmails
,CAST(convert( varchar(11), dbo.udfUTCtoDaylightSavingTime(DATEADD(d,1,GETUTCDATE()),@OrgID),113) AS DateTime) as Tomorrow
,CASE when tblUser.usertypeid=4 then dbo.udfUser_GetAdministratorsEmailAddress (tblUser.UserID) else tblUser.Email end as SenderEmail
,IsPeriodic
FROM
tblReportinterface
inner join tblReportSchedule RS  on tblReportinterface.ReportID = RS.ReportID
INNER JOIN tblUser ON RS.UserID = tblUser.UserID
LEFT OUTER JOIN tblLang ON tblLang.LangCode = RS.ParamLangCode
LEFT OUTER JOIN tblLangInterface ON  paramlanginterfacename = tblLangInterface.langinterfacename
LEFT OUTER JOIN tblLangResource ON  tblLangResource.langresourcename = 'rptreporttitle'
LEFT OUTER JOIN tblLangValue ON tblLang.LangID = tblLangValue.LangID   AND (tblLangValue.Active = 1) and tblLangValue.LangInterfaceID = tblLangInterface.LangInterfaceID and tblLangValue.LangResourceID = tblLangResource.LangResourceID

WHERE ScheduleID = @ScheduleID


END

GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[prcReport_GetNextUrgentReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[prcReport_GetNextUrgentReport]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[prcReport_GetNextUrgentReport]

AS
BEGIN
-- Only returns NOW schedules - Send these first to give a greater sense of response by the application
-- NEXTRUN is always saved in UTC to reduce conversion times
-- NextRun is never null
SET NOCOUNT ON

DECLARE @ScheduleID int,
@RunDate datetime,
@ReportStartDate datetime,
@ReportFrequencyPeriod char(1),
@ReportFrequency int,
@OrgID int	,
@ReportFromDate datetime,
@NumberDelivered int,
@NumberOfReports int,
@ReportEndDate datetime,
@ReportPeriodType int,
@ReportID int,
@DateFrom DateTime

UPDATE tblReportSchedule -- remove schedules for inactive users
SET NumberDelivered = 0,
TerminatedNormally = 1,
LastRun = getUTCdate(),
NextRun = null
WHERE ScheduleID in
(
SELECT ScheduleID
FROM tblReportSchedule
INNER JOIN tblUser ON tblReportSchedule.UserID = tblUser.UserID
WHERE (TerminatedNormally = 0)
AND (IsPeriodic = 'N')
AND (tblUser.Active = 0)
)

SELECT @ScheduleID = ScheduleID
FROM tblReportSchedule
INNER JOIN tblReportInterface ON tblReportSchedule.ReportID = tblReportInterface.ReportID
INNER JOIN tblUser ON tblReportSchedule.UserID = tblUser.UserID
INNER JOIN tblOrganisation ON tblOrganisation.OrganisationID = tblReportSchedule.ParamOrganisationID
WHERE  CourseStatusLastUpdated > dbo.udfGetSaltOrgMidnight(tblUser.OrganisationID)
AND (TerminatedNormally = 0)
AND (IsPeriodic = 'N')
AND (tblUser.Active = 1)

DECLARE @OnBehalfOf nvarchar(255)
DECLARE @ReplyTo nvarchar(255)
DECLARE @FromDate DateTime = CAST('1 Jan 2002' as datetime)

IF (@ScheduleID IS NOT NULL)
BEGIN
DECLARE @NextRun datetime
SELECT @NextRun = NextRun,
@ReportStartDate = ReportStartDate,
@ReportFrequencyPeriod = ReportFrequencyPeriod,
@ReportFrequency = ReportFrequency,
@OrgID = ParamOrganisationID,
@ReportFromDate = ReportFromDate,
@NumberDelivered = NumberDelivered,
@NumberOfReports = NumberOfReports,
@ReportEndDate = ReportEndDate ,
@ReportPeriodType = coalesce(ReportPeriodType ,3),
@ReportID = ReportID,
@DateFrom = ParamDateFrom
FROM tblReportSchedule WHERE ScheduleID = @ScheduleID

-- update the Report Schedule
UPDATE tblReportSchedule
SET NumberDelivered = NumberDelivered + 1,
TerminatedNormally = 1,
LastRun = getUTCdate(),
NextRun = cast('1 jan 2050' as datetime),
LastUpdatedBy=0,
Lastupdated=getUTCdate()
WHERE ScheduleID = @ScheduleID



-- we know the 'to' date - just need to read the 'from' date
SET @FromDate = @ReportStartDate



END -- IF ScheduleID is not null


-- return the results
SET NOCOUNT OFF
SELECT TOP (1) [ScheduleID]
,RS.UserID
,RS.ReportID
,[LastRun]
,[ReportStartDate]
,[ReportFrequency]
,[ReportFrequencyPeriod]
,[DocumentType]
,[ParamOrganisationID]
,[ParamCompleted]
,[ParamStatus]
,[ParamFailCount]
,[ParamCourseIDs]
,[ParamHistoricCourseIDs]
,[ParamAllUnits]
,[ParamTimeExpired]
,[ParamTimeExpiredPeriod]
,[ParamQuizStatus]
,[ParamGroupBy]
,[ParamGroupingOption]
,[ParamFirstName]
,[ParamLastName]
,[ParamUserName]
,[ParamEmail]
,[ParamIncludeInactive]
,[ParamSubject]
,[ParamBody]
,[ParamProfileID]
,[ParamProfilePeriodID]
,[ParamPolicyIDs]
,[ParamAcceptance]
,[ParamOnlyUsersWithShortfall]
,[ParamEffectiveDate]
,[ParamSortBy]
,[ParamClassificationID]
,ParamLangInterfaceName
, case
when tblReportinterface.ReportID = 26 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.2'))
when tblReportinterface.ReportID = 27 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.2'))
when tblReportinterface.ReportID = 3 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.1'))
when tblReportinterface.ReportID = 6 then (select coalesce(LangEntryValue,'Missing Localisation') from tblLangValue where tblLangValue.LangID = (SELECT LangID FROM tblLang where tblLang.LangCode = RS.ParamLangCode) and LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = '/Reporting/Admin/AdministrationReport.aspx') and LangResourceID = (select LangResourceID from tblLangResource where LangResourceName = 'lblPageTitle.1'))
when (tblReportinterface.ReportID = 22) or (tblReportinterface.ReportID = 23) or (tblReportinterface.ReportID = 24) or (tblReportinterface.ReportID = 10)
then
(
select coalesce(LangEntryValue, (select coalesce(tblLangValue.LangEntryValue,'Missing Localisation') FROM tblLangValue where tblLang.LangID = tblLangValue.LangID   AND (tblLangValue.Active = 1) and tblLangValue.LangInterfaceID = (select LangInterfaceID from tblLangInterface where LangInterfaceName = 'Report.Summary') and tblLangValue.LangResourceID = tblLangResource.LangResourceID))
)

else coalesce(tblLangValue.LangEntryValue,'Missing Localisation')
end as ReportName
,tblReportInterface.RDLname
,tblUser.FirstName
,tblUser.LastName
,tblUser.Email
,ParamUnitIDs
,paramOrganisationID
,RS.ParamLangCode
,ParamLangCode
,ParamLicensingPeriod
,RS.ReportEndDate
,RS.ReportTitle
,RS.NumberOfReports
,RS.ReportFromDate
,(dbo.udfGetCCList(RS.ScheduleID)) as CCList
,RS.ReportPeriodType
,dbo.udfGetEmailOnBehalfOf (ParamOrganisationID) as OnBehalfOf
,RS.NextRun
,RS.ReportFromDate
,@FromDate as FromDate
,dbo.udfGetEmailReplyTo (ParamOrganisationID,tblUser.FirstName + ' ' + tblUser.LastName + ' <' + tblUser.Email + '>') as ReplyTo
,CASE when exists (SELECT Value FROM  tblAppConfig WHERE (Name = 'SEND_AUTO_EMAILS') AND (UPPER(Value) = 'YES')) then 0 ELSE 1 END as StopEmails
,CAST(convert( varchar(11), dbo.udfUTCtoDaylightSavingTime(DATEADD(d,1,GETUTCDATE()),@OrgID),113) AS DateTime) as Tomorrow
,CASE when tblUser.usertypeid=4 then dbo.udfUser_GetAdministratorsEmailAddress (tblUser.UserID) else tblUser.Email end as SenderEmail
,IsPeriodic
FROM
tblReportinterface
inner join tblReportSchedule RS  on tblReportinterface.ReportID = RS.ReportID
INNER JOIN tblUser ON RS.UserID = tblUser.UserID
LEFT OUTER JOIN tblLang ON tblLang.LangCode = RS.ParamLangCode
LEFT OUTER JOIN tblLangInterface ON  paramlanginterfacename = tblLangInterface.langinterfacename
LEFT OUTER JOIN tblLangResource ON  tblLangResource.langresourcename = 'rptreporttitle'
LEFT OUTER JOIN tblLangValue ON tblLang.LangID = tblLangValue.LangID   AND (tblLangValue.Active = 1) and tblLangValue.LangInterfaceID = tblLangInterface.LangInterfaceID and tblLangValue.LangResourceID = tblLangResource.LangResourceID

WHERE ScheduleID = @ScheduleID


-- remove spent "NOW" Schedule to reduce size of table
DELETE FROM tblReportSchedule
WHERE ScheduleID = @ScheduleID

END

GO


